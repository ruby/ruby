1000000.times.map{|i| a={}; 2.times{|j| a[j]=j}; a}
